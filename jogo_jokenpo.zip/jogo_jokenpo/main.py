from jokenpo_util import simnao, instrucoes, gerar_jogada_pc, pergunta_jogada_humano, avaliar_jogada, imprimir_placar
continuar = True

def main():
    '''função principal do programa'''
    if not simnao('Desejar começar?'):
        return
    continuar = True
    instrucoes()
    n_jogada = p_pc = p_humano = 0
    while n_jogada < 7:
        print('\nJogada #', n_jogada+1)
        n_jogada += 1
        j_pc = gerar_jogada_pc()
        j_hu = pergunta_jogada_humano()
        if not j_hu:
            break
        reultado = avaliar_jogada(j_pc,j_hu)
        if reultado == -1:
            p_pc += 1
        elif reultado == 1:
            p_humano += 1
    imprimir_placar(p_pc,p_humano)

if __name__ == '__main__':
    main()
